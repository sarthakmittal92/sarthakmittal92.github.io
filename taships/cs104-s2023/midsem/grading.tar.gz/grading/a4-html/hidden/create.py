for i in range(1,100000001):
    print(i)
